#include <stddef.h>
#include <stdint.h>

static void outb(uint16_t port, uint8_t value) {
	asm("outb %0,%1" : /* empty */ : "a" (value), "Nd" (port) : "memory");
}

static inline void out32(uint16_t port, uint32_t value) {
	asm("out %0,%1" : /* empty */ : "a" (value), "Nd" (port) : "memory");
}

static inline uint32_t in32(uint16_t port) {
	uint32_t ret;
	asm("in %1, %0" : "=a"(ret) : "Nd"(port) : "memory" );
	return ret;
}

static inline void printVal(uint32_t value) {
	out32(0xE1, value);
}

static inline uint32_t getNumExits() {
	return in32(0xE2);
}

static inline void display(const char *str) {
	out32(0xE3, (uintptr_t)str);
}

static inline uint32_t mOpen(const char* path, int flags) {
	uint32_t args[2] = { (uintptr_t)path, flags};
	out32(0xE4, (uintptr_t)args);
	return in32(0xE4);
}

static inline uint32_t mRead(int fd, void *buf, size_t count){
	uint32_t args[3] = {fd, (uintptr_t)buf, count};
	out32(0xE5, (uintptr_t)args);
	return in32(0xE5);
}

static inline uint32_t mWrite(int fd, void *buf, size_t count){
	uint32_t args[3] = {fd, (uintptr_t)buf, count};
	out32(0xE6, (uintptr_t)args);
	return in32(0xE6);
}

static inline uint32_t mSeek(int fd, uint32_t offset, int whence){
	uint32_t args[3] = { fd, offset, whence };
	out32(0xE7, (uintptr_t)args);
	return in32(0xE7);
}

static inline uint32_t mClose(uint32_t fd) {
	out32(0xE8, fd);
	return in32(0xE8);
}


void
__attribute__((noreturn))
__attribute__((section(".start")))
_start(void) {
	const char *p;
	for (p = "Hello, world!\n"; *p; ++p)
		outb(0xE9, *p);

	// uint32_t val = 1234;
	// printVal(val);

	uint32_t numExits = getNumExits();
	printVal(numExits);

	display("Hello, world!");
	printVal(getNumExits());
	// Increase is 3 because of display, printVal, getNumExits


	int file = mOpen("dummy.txt", 2);
	printVal(file);

	printVal(mWrite(file, "Hari Krishna", 12));

	char buffer[100];
	printVal(mSeek(file, 0, 0));
	printVal(mRead(file, buffer, 5));
	display(buffer);

	printVal(mSeek(file, 5, 0));
	printVal(mRead(file, buffer, 7));
	display(buffer);

	printVal(mClose(file));

	int file1 = mOpen("dummy.txt", 2);
	printVal(file1);
	int file2 = mOpen("Makefile", 2);
	printVal(file2);

	printVal(mClose(file1));
	printVal(mClose(file2));


	*(long *) 0x400 = 42;
	for (;;)
		asm("hlt" : /* empty */ : "a" (42) : "memory");
}
