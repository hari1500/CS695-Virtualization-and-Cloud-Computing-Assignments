import libvirt
import sys
import socket
import threading
import logging
import time

logging.basicConfig(level=logging.DEBUG, format='(%(threadName)-9s) %(message)s',)
PORT = 8080
MAX_ITER = 100
SLEEP_TIME = 1

def get_dom_ip_pairs(conn, filter):
    dom_ip_pairs = []

    for dom in conn.listAllDomains(filter):
        dom_ip = (dom, None)
        ifaces = dom.interfaceAddresses(0)

        for (name, val) in ifaces.items():
            if val['addrs']:
                for ipaddr in val['addrs']:
                    if ipaddr['type'] == libvirt.VIR_IP_ADDR_TYPE_IPV4:
                        dom_ip = (dom, ipaddr['addr'])
        
        dom_ip_pairs.append(dom_ip)

    return dom_ip_pairs

def valid_ip(address):
    try:
        parts = address.split(".")
        if len(parts) != 4:
            return False
        for item in parts:
            if not 0 <= int(item) <= 255:
                return False
    except Exception:
        return False

    return True

def send_request(ip):
    if not valid_ip(ip):
        return

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ip, PORT))
        s.send(b'10000000')
        data = s.recv(1024)
        logging.debug('Received %s' % data.decode())

def monitor_doms(conn):
    while True:
        for dom in conn.listAllDomains(libvirt.VIR_CONNECT_LIST_DOMAINS_RUNNING):
            time.sleep(SLEEP_TIME)
            cpu_stats = dom.getCPUStats(True)
            cpu_time1 = cpu_stats[0]['cpu_time']
            time.sleep(SLEEP_TIME)
            cpu_stats = dom.getCPUStats(True)
            cpu_time2 = cpu_stats[0]['cpu_time']

            cpu_usage = ((cpu_time2-cpu_time1) * 100) / (SLEEP_TIME*1000000000)

            logging.debug('CPU usage of %s is %s' % (dom.name(), cpu_usage))
    

if __name__ == "__main__":
    # Creating connection to qemu
    conn = libvirt.open('qemu:///system')
    if conn == None:
        print('Failed to open connection to qemu:///system', file=sys.stderr)
        exit(1)

    # threads for monitoring running domains
    monitor_thread = threading.Thread(name="monitor", target=monitor_doms, args=(conn,))
    monitor_thread.start()

    # sending requests to running domains
    num_iter = 0
    request_threads = []
    while num_iter < MAX_ITER:

        num_iter += 1
        for dom_ip in get_dom_ip_pairs(conn, libvirt.VIR_CONNECT_LIST_DOMAINS_RUNNING):
            t_name = "%s_%s" % (dom_ip[0].name(), num_iter)
            t = threading.Thread(name=t_name, target=send_request, args=(dom_ip[1],))
            t.start()
            request_threads.append(t)
        time.sleep(SLEEP_TIME)

    # Joining all threads created
    for t in request_threads:
        t.join()
    monitor_thread.join()

    # Closing connection to qemu
    conn.close()
    exit(0)
    