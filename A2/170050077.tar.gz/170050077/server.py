import socket
import threading

PORT = 8080

def factorial(n=0):
    if n == 0:
        return 1
    return n * factorial(n-1)

def some_computation(n=0):
    x = 0
    for i in range(n):
        x = i
    return

def get_my_ip_addr():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(('10.255.255.255', 0))
        ipaddr = sock.getsockname()[0]
    except Exception:
        ipaddr = '127.0.0.1'
    finally:
        sock.close()

    return ipaddr

def manage_request(client_socket, client_addr):
    try:
        data = client_socket.recv(1024)
        data = data.decode()
        data = int(data)
        # factorial(data)
        some_computation(data)
        client_socket.send(b'Done')
    except Exception as err:
        print(err)
    return


if __name__ == "__main__":
    # Accepting sockets
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((get_my_ip_addr(), PORT))
        s.listen()

        while True:
            client_socket, client_addr = s.accept()
            threading.Thread(target=manage_request, args=(client_socket, client_addr,)).start()
        