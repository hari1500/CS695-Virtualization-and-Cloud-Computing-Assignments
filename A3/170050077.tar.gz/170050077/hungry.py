f = open("/dev/urandom", "rb")
data = b""

i=0
while True:
    data += f.read(10000000) # 10mb
    i += 1
    print("%dmb" % (i*10,))
