#define _GNU_SOURCE
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sched.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#define errExit(msg)  do { perror(msg); exit(EXIT_FAILURE); } while (0)

static int childFunc(void *arg) 
{
    // Taking inputs
    char rootfs[32], hostname[32];
    int container_num = atoi(arg);
    printf("Enter root filesystem path: ");
    scanf("%31s", rootfs);
    printf("Enter hostname: ");
    scanf("%31s", hostname);
    printf("\n");

    // setting hostname
    if (sethostname(hostname, strlen(hostname)) == -1)
    {
        errExit("sethostname");
    }

    int buf_size = 1024, fd;
    char str_buf[buf_size];

    // attaching network namespace
    snprintf(str_buf, buf_size, "/var/run/netns/netns%d", container_num);
    fd = open(str_buf, O_RDONLY | O_CLOEXEC);
    if (fd < 0)
    {
        errExit("network namespace");
    }
    if (setns(fd, CLONE_NEWNET) < 0)
    {
        errExit("setns");
    }

    // starting cgroups
    snprintf(str_buf, buf_size, "sudo mkdir /sys/fs/cgroup/memory/memcgrp%d", container_num);
    printf("%s\n", str_buf);
    system(str_buf);

    snprintf(str_buf, buf_size, "sudo echo '100000000' > /sys/fs/cgroup/memory/memcgrp%d/memory.limit_in_bytes", container_num);
    printf("%s\n", str_buf);
    system(str_buf);

    snprintf(str_buf, buf_size, "sudo echo '0' > /sys/fs/cgroup/memory/memcgrp%d/memory.swappiness", container_num);
    printf("%s\n", str_buf);
    system(str_buf);

    snprintf(str_buf, buf_size, "sudo echo '%d' > /sys/fs/cgroup/memory/memcgrp%d/tasks", getpid(), container_num);
    printf("%s\n", str_buf);
    system(str_buf);

    printf("\n");


    printf(".....Starting shell.....\n");

    snprintf(str_buf, buf_size, "sudo unshare -p -f --mount-proc=$PWD/%s/proc chroot %s /bin/bash", rootfs, rootfs);
    printf("%s\n", str_buf);
    system(str_buf);
    printf("\n");

    // exiting cgroup
    snprintf(str_buf, buf_size, "sudo rmdir /sys/fs/cgroup/memory/memcgrp%d", container_num);
    printf("%s\n", str_buf);
    system(str_buf);
    printf("\n");

   return 0;
}

#define STACK_SIZE (1024 * 1024)


int main (int argc, char* argv[])
{
    int container_num = atoi(argv[1]);
    int buf_size = 1024, fd;
    char str_buf[buf_size];

    snprintf(str_buf, buf_size, "/var/run/netns/netns%d", container_num);
    fd = open(str_buf, O_RDONLY | O_CLOEXEC);
    if (fd <= 0)
    {
        snprintf(str_buf, buf_size, "sudo ip netns add netns%d", container_num);
        printf("%s\n", str_buf);
        system(str_buf);

        snprintf(str_buf, buf_size, "sudo ip link add v-eth%d type veth peer name v-peer%d", container_num, container_num);
        printf("%s\n", str_buf);
        system(str_buf);

        snprintf(str_buf, buf_size, "sudo ip link set v-peer%d netns netns%d", container_num, container_num);
        printf("%s\n", str_buf);
        system(str_buf);

        snprintf(str_buf, buf_size, "sudo ip netns exec netns%d ifconfig v-peer%d 10.1.%d.1/24 up", container_num, container_num, container_num);
        printf("%s\n", str_buf);
        system(str_buf);

        snprintf(str_buf, buf_size, "sudo ip netns exec netns%d ip link set dev lo up", container_num);
        printf("%s\n", str_buf);
        system(str_buf);

        snprintf(str_buf, buf_size, "sudo ifconfig v-eth%d 10.1.%d.2/24 up", container_num, container_num);
        printf("%s\n", str_buf);
        system(str_buf);

        printf("\n");
    }


    char *stack = malloc(STACK_SIZE);
    if (stack == NULL) 
    {
       errExit("malloc");
    }
    char *stackTop = stack + STACK_SIZE;

    /* Create child and commences execution in childFunc() */
    pid_t pid = clone(childFunc, stackTop, CLONE_NEWUTS | CLONE_NEWNET | SIGCHLD, argv[1]);
    if (pid == -1) 
    {
       errExit("clone");
    }

    /* Parent falls through to here and Give child time to change its hostname */
    sleep(1);
    /* Wait for child */
    if (waitpid(pid, NULL, 0) == -1)
    {
        errExit("waitpid");
    }
    // printf("\nChild has terminated\n");

    exit(EXIT_SUCCESS);

    return 0;
}
